make_url <- function(dataset, year, month, vars, key) {

  month_abb <- tolower(month.abb[month])
  collapsed_vars <- toupper(paste(vars, collapse = ","))

  url <- httr::modify_url(
    url = "https://api.census.gov",
    path = paste("data", year, "cps", dataset, month_abb, sep = "/"),
    query = list(get = collapsed_vars, key = key)
  )

  url
}

url<-make_url("asec",2023,3, c("GESTFIPS", "GTCO","FTOTVAL", "FTOT_R"), key = "b74a1af943e871e01d52d59180e89ed40de89c7d")
ua <- httr::user_agent("https://github.com/matt-saenz/cpsR")
resp <- httr::GET(url, ua)
mat <- jsonlite::fromJSON(httr::content(resp, as = "text"))
cps_tibble<- mat %>% as_tibble()


# Set the column names to the values of the first row
colnames(cps_tibble) <- as.character(unlist(cps_tibble[1, ]))

# Remove the first row
cps_tibble <- cps_tibble[-1, ]
